
import { useState, useEffect } from 'react';
import Head from 'next/head';

export default function Home() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') setDarkMode(true);
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
      <Head>
        <title>OR UNITY - سيرفر ماينكرافت</title>
        <meta name="description" content="سيرفر OR UNITY - مود Lifesteal - إصدار Java & Bedrock" />
      </Head>

      <header className="flex justify-between items-center p-4 border-b dark:border-gray-700">
        <h1 className="text-2xl font-bold">سيرفر OR UNITY</h1>
        <button
          className="px-4 py-2 rounded bg-gray-200 dark:bg-gray-700"
          onClick={() => setDarkMode(!darkMode)}
        >
          {darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
        </button>
      </header>

      <main className="p-6 space-y-10">
        <section>
          <h2 className="text-xl font-semibold mb-2">عن السيرفر</h2>
          <p>
            سيرفر OR UNITY يقدم تجربة لعب رائعة بنظام Lifesteal التنافسي. السيرفر يعمل على إصدار Java، وأحياناً يتم دعمه لإصدار Bedrock.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">طريقة الدخول</h2>
          <p>
            افتح ماينكرافت، أدخل على Multiplayer، ثم أضف السيرفر بعنوان: <strong>orunity.buy</strong> (سيتم تفعيله لاحقًا)
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">الرتب والمتجر</h2>
          <p>
            سيتم قريباً إضافة متجر لشراء الرتب والعناصر الخاصة داخل اللعبة. تابعنا على وسائل التواصل لمزيد من التفاصيل.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-2">الدعم والتواصل</h2>
          <p>
            لأي استفسار أو مشكلة، يمكنك التواصل معنا عبر الروابط التي سيتم إضافتها هنا لاحقاً.
          </p>
        </section>
      </main>

      <footer className="text-center p-4 border-t dark:border-gray-700">
        <p>جميع الحقوق محفوظة &copy; OR UNITY - 2025</p>
      </footer>
    </div>
  );
}
